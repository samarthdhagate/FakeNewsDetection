import { TrainingData } from '../types';

export const parseCSV = (csvContent: string): Promise<TrainingData[]> => {
  return new Promise((resolve, reject) => {
    try {
      const lines = csvContent.trim().split('\n');
      
      if (lines.length < 2) {
        throw new Error('CSV must have at least a header and one data row');
      }
      
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      
      // Find text and label columns
      const textIndex = headers.findIndex(h => 
        h.includes('text') || h.includes('content') || h.includes('article') || h.includes('news')
      );
      
      const labelIndex = headers.findIndex(h => 
        h.includes('label') || h.includes('class') || h.includes('category') || h.includes('type')
      );
      
      if (textIndex === -1 || labelIndex === -1) {
        throw new Error('CSV must contain columns for text content and labels (fake/real)');
      }
      
      const data: TrainingData[] = [];
      
      for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);
        
        if (values.length > Math.max(textIndex, labelIndex)) {
          const text = values[textIndex]?.trim();
          const label = values[labelIndex]?.trim().toLowerCase();
          
          if (text && (label === 'fake' || label === 'real' || label === '1' || label === '0')) {
            data.push({
              text,
              label: (label === 'fake' || label === '1') ? 'fake' : 'real'
            });
          }
        }
      }
      
      if (data.length === 0) {
        throw new Error('No valid training data found. Ensure labels are "fake"/"real" or "1"/"0"');
      }
      
      resolve(data);
    } catch (error) {
      reject(error);
    }
  });
};

const parseCSVLine = (line: string): string[] => {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"' && (i === 0 || line[i - 1] === ',')) {
      inQuotes = true;
    } else if (char === '"' && inQuotes && (i === line.length - 1 || line[i + 1] === ',')) {
      inQuotes = false;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current.trim());
  return result;
};