import { HashTable } from '../dataStructures/HashTable';
import { BST } from '../dataStructures/BST';
import { Stack } from '../dataStructures/Stack';
import { PriorityQueue } from '../dataStructures/PriorityQueue';
import { TrainingData, AnalysisResult, KeywordEntry } from '../types';

export class FakeNewsDetector {
  private keywordHash: HashTable<KeywordEntry>;
  private suspiciousPhraseBST: BST<string>;
  private factualIndicatorHash: HashTable<number>;
  private emotionalWordHash: HashTable<number>;

  constructor() {
    this.keywordHash = new HashTable<KeywordEntry>(2000);
    this.suspiciousPhraseBST = new BST<string>((a, b) => a.localeCompare(b));
    this.factualIndicatorHash = new HashTable<number>();
    this.emotionalWordHash = new HashTable<number>();
    
    this.initializeFactualIndicators();
    this.initializeEmotionalWords();
  }

  private initializeFactualIndicators(): void {
    const factualWords = [
      'according', 'research', 'study', 'data', 'statistics', 'report',
      'analysis', 'evidence', 'survey', 'poll', 'investigation', 'findings',
      'documented', 'verified', 'confirmed', 'official', 'published',
      'peer-reviewed', 'scientific', 'academic'
    ];

    factualWords.forEach(word => {
      this.factualIndicatorHash.set(word, 1);
    });
  }

  private initializeEmotionalWords(): void {
    const emotionalWords = [
      'shocking', 'amazing', 'incredible', 'unbelievable', 'outrageous',
      'devastating', 'terrifying', 'mind-blowing', 'explosive', 'sensational',
      'controversial', 'scandalous', 'dramatic', 'alarming', 'disturbing',
      'urgent', 'breaking', 'exclusive', 'secret', 'hidden'
    ];

    emotionalWords.forEach(word => {
      this.emotionalWordHash.set(word, 1);
    });
  }

  train(trainingData: TrainingData[]): void {
    console.log(`Training with ${trainingData.length} samples...`);
    
    // Reset training data
    this.keywordHash = new HashTable<KeywordEntry>(2000);
    this.suspiciousPhraseBST = new BST<string>((a, b) => a.localeCompare(b));

    // Process each training sample
    trainingData.forEach(sample => {
      this.processTrainingSample(sample);
    });

    // Extract suspicious phrases (phrases that appear more in fake news)
    this.extractSuspiciousPhrases(trainingData);
    
    console.log('Training completed!');
  }

  private processTrainingSample(sample: TrainingData): void {
    const words = this.preprocessText(sample.text);
    
    words.forEach(word => {
      if (word.length > 2) { // Filter out very short words
        let entry = this.keywordHash.get(word);
        
        if (!entry) {
          entry = { word, fakeCount: 0, realCount: 0, weight: 0 };
          this.keywordHash.set(word, entry);
        }
        
        if (sample.label === 'fake') {
          entry.fakeCount++;
        } else {
          entry.realCount++;
        }
        
        // Calculate weight (higher for words that appear more in fake news)
        const total = entry.fakeCount + entry.realCount;
        entry.weight = total > 0 ? (entry.fakeCount / total) : 0;
        
        this.keywordHash.set(word, entry);
      }
    });
  }

  private extractSuspiciousPhrases(trainingData: TrainingData[]): void {
    const phraseMap = new Map<string, { fake: number; real: number }>();
    
    // Extract 2-3 word phrases
    trainingData.forEach(sample => {
      const words = this.preprocessText(sample.text);
      
      // 2-word phrases
      for (let i = 0; i < words.length - 1; i++) {
        const phrase = `${words[i]} ${words[i + 1]}`;
        if (!phraseMap.has(phrase)) {
          phraseMap.set(phrase, { fake: 0, real: 0 });
        }
        
        const count = phraseMap.get(phrase)!;
        if (sample.label === 'fake') {
          count.fake++;
        } else {
          count.real++;
        }
      }
      
      // 3-word phrases
      for (let i = 0; i < words.length - 2; i++) {
        const phrase = `${words[i]} ${words[i + 1]} ${words[i + 2]}`;
        if (!phraseMap.has(phrase)) {
          phraseMap.set(phrase, { fake: 0, real: 0 });
        }
        
        const count = phraseMap.get(phrase)!;
        if (sample.label === 'fake') {
          count.fake++;
        } else {
          count.real++;
        }
      }
    });
    
    // Add phrases that are more common in fake news to BST
    phraseMap.forEach((count, phrase) => {
      const total = count.fake + count.real;
      const fakeRatio = count.fake / total;
      
      // If phrase appears more in fake news and has reasonable frequency
      if (fakeRatio > 0.6 && total > 2) {
        this.suspiciousPhraseBST.insert(phrase);
      }
    });
  }

  private preprocessText(text: string): string[] {
    return text
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 0);
  }

  analyze(text: string): AnalysisResult {
    const words = this.preprocessText(text);
    const analysisStack = new Stack<string>();
    const scoreQueue = new PriorityQueue<{ word: string; score: number }>();
    
    // Push words to stack for processing
    words.forEach(word => analysisStack.push(word));
    
    let suspiciousScore = 0;
    let factualScore = 0;
    let emotionalScore = 0;
    const suspiciousKeywords: string[] = [];
    
    // Process words from stack
    while (!analysisStack.isEmpty()) {
      const word = analysisStack.pop()!;
      
      // Check keyword hash
      const entry = this.keywordHash.get(word);
      if (entry && entry.weight > 0.6) {
        suspiciousScore += entry.weight;
        suspiciousKeywords.push(word);
        
        scoreQueue.enqueue(
          { word, score: entry.weight },
          1 - entry.weight // Lower priority value = higher priority
        );
      }
      
      // Check factual indicators
      if (this.factualIndicatorHash.has(word)) {
        factualScore++;
      }
      
      // Check emotional words
      if (this.emotionalWordHash.has(word)) {
        emotionalScore++;
      }
    }
    
    // Check suspicious phrases using BST
    const suspiciousPhrases = this.suspiciousPhraseBST.findMatches(text);
    suspiciousScore += suspiciousPhrases.length * 0.5;
    
    // Calculate final scores
    const totalWords = words.length;
    const suspiciousWordCount = suspiciousKeywords.length + suspiciousPhrases.length;
    const factDensityScore = totalWords > 0 ? factualScore / totalWords : 0;
    const emotionalRatio = totalWords > 0 ? emotionalScore / totalWords : 0;
    
    // Determine verdict based on multiple factors
    const suspiciousRatio = totalWords > 0 ? suspiciousScore / totalWords : 0;
    const combinedScore = suspiciousRatio + (emotionalRatio * 0.3) - (factDensityScore * 0.5);
    
    const isFake = combinedScore > 0.15;
    const confidence = Math.min(Math.abs(combinedScore) * 100, 95);
    
    return {
      verdict: isFake ? 'fake' : 'real',
      confidence: Math.round(confidence),
      suspiciousKeywords: [...new Set(suspiciousKeywords)],
      factDensityScore: Math.round(factDensityScore * 100),
      details: {
        totalWords,
        suspiciousWordCount,
        factualIndicators: factualScore,
        emotionalWords: emotionalScore
      }
    };
  }
}