import React from 'react';
import { AlertTriangle, CheckCircle, TrendingUp, Eye, Hash, BarChart3 } from 'lucide-react';
import { AnalysisResult as AnalysisResultType } from '../types';

interface AnalysisResultProps {
  result: AnalysisResultType;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ result }) => {
  const isFake = result.verdict === 'fake';
  
  const getVerdictColor = () => {
    if (isFake) {
      return result.confidence > 80 ? 'red' : result.confidence > 60 ? 'orange' : 'yellow';
    } else {
      return result.confidence > 80 ? 'green' : result.confidence > 60 ? 'blue' : 'gray';
    }
  };

  const color = getVerdictColor();
  
  const colorClasses = {
    red: {
      bg: 'bg-red-50',
      border: 'border-red-200',
      text: 'text-red-800',
      icon: 'text-red-600',
      badge: 'bg-red-100 text-red-800',
      progress: 'bg-red-500'
    },
    orange: {
      bg: 'bg-orange-50',
      border: 'border-orange-200',
      text: 'text-orange-800',
      icon: 'text-orange-600',
      badge: 'bg-orange-100 text-orange-800',
      progress: 'bg-orange-500'
    },
    yellow: {
      bg: 'bg-yellow-50',
      border: 'border-yellow-200',
      text: 'text-yellow-800',
      icon: 'text-yellow-600',
      badge: 'bg-yellow-100 text-yellow-800',
      progress: 'bg-yellow-500'
    },
    green: {
      bg: 'bg-green-50',
      border: 'border-green-200',
      text: 'text-green-800',
      icon: 'text-green-600',
      badge: 'bg-green-100 text-green-800',
      progress: 'bg-green-500'
    },
    blue: {
      bg: 'bg-blue-50',
      border: 'border-blue-200',
      text: 'text-blue-800',
      icon: 'text-blue-600',
      badge: 'bg-blue-100 text-blue-800',
      progress: 'bg-blue-500'
    },
    gray: {
      bg: 'bg-gray-50',
      border: 'border-gray-200',
      text: 'text-gray-800',
      icon: 'text-gray-600',
      badge: 'bg-gray-100 text-gray-800',
      progress: 'bg-gray-500'
    }
  };

  const classes = colorClasses[color as keyof typeof colorClasses];

  return (
    <div className="space-y-6">
      {/* Main Verdict */}
      <div className={`rounded-lg p-6 ${classes.bg} border ${classes.border}`}>
        <div className="flex items-center space-x-3 mb-4">
          {isFake ? (
            <AlertTriangle className={`w-8 h-8 ${classes.icon}`} />
          ) : (
            <CheckCircle className={`w-8 h-8 ${classes.icon}`} />
          )}
          <div>
            <h3 className={`text-2xl font-bold ${classes.text}`}>
              {result.verdict.toUpperCase()}
            </h3>
            <p className={`${classes.text} opacity-75`}>
              {isFake ? 'Potentially unreliable content detected' : 'Content appears reliable'}
            </p>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className={`text-sm font-medium ${classes.text}`}>Confidence Score</span>
            <span className={`text-lg font-bold ${classes.text}`}>{result.confidence}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className={`h-3 rounded-full ${classes.progress} transition-all duration-1000 ease-out`}
              style={{ width: `${result.confidence}%` }}
            />
          </div>
        </div>
      </div>

      {/* Detailed Analysis */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Statistics */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span>Analysis Statistics</span>
          </h4>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Total Words</span>
              <span className="font-semibold text-gray-900">{result.details.totalWords}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Suspicious Words</span>
              <span className="font-semibold text-gray-900">{result.details.suspiciousWordCount}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Factual Indicators</span>
              <span className="font-semibold text-gray-900">{result.details.factualIndicators}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Emotional Words</span>
              <span className="font-semibold text-gray-900">{result.details.emotionalWords}</span>
            </div>
            <div className="pt-2 border-t border-gray-200">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Fact Density Score</span>
                <span className="font-bold text-blue-600">{result.factDensityScore}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Suspicious Keywords */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <Hash className="w-5 h-5 text-orange-600" />
            <span>Suspicious Keywords</span>
          </h4>
          {result.suspiciousKeywords.length > 0 ? (
            <div className="space-y-2">
              {result.suspiciousKeywords.slice(0, 8).map((keyword, index) => (
                <span
                  key={index}
                  className="inline-block bg-orange-100 text-orange-800 text-xs font-medium px-2.5 py-1 rounded-full mr-2 mb-2"
                >
                  {keyword}
                </span>
              ))}
              {result.suspiciousKeywords.length > 8 && (
                <p className="text-xs text-gray-500 mt-2">
                  +{result.suspiciousKeywords.length - 8} more keywords detected
                </p>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-500 italic">No suspicious keywords detected</p>
          )}
        </div>
      </div>

      {/* Data Structure Insights */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
          <Eye className="w-5 h-5 text-purple-600" />
          <span>Data Structure Analysis</span>
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h5 className="font-semibold text-blue-800 text-sm mb-1">Hash Tables</h5>
            <p className="text-xs text-blue-600">Used for O(1) keyword lookup</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <h5 className="font-semibold text-green-800 text-sm mb-1">Binary Search Tree</h5>
            <p className="text-xs text-green-600">Organized suspicious phrases</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <h5 className="font-semibold text-purple-800 text-sm mb-1">Stack</h5>
            <p className="text-xs text-purple-600">Processed text sequentially</p>
          </div>
          <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
            <h5 className="font-semibold text-orange-800 text-sm mb-1">Priority Queue</h5>
            <p className="text-xs text-orange-600">Ranked keywords by importance</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisResult;