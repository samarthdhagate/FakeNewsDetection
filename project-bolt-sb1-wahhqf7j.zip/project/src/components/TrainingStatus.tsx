import React from 'react';
import { CheckCircle, Database, Hash, Binary, Layers } from 'lucide-react';

interface TrainingStatusProps {
  isTraining: boolean;
  isTrainingComplete: boolean;
  trainingDataSize: number;
}

const TrainingStatus: React.FC<TrainingStatusProps> = ({
  isTraining,
  isTrainingComplete,
  trainingDataSize,
}) => {
  if (!isTraining && !isTrainingComplete) {
    return null;
  }

  const dataStructures = [
    { name: 'Hash Tables', icon: Hash, description: 'Keyword lookup optimization' },
    { name: 'Binary Search Tree', icon: Binary, description: 'Suspicious phrase storage' },
    { name: 'Stack', icon: Layers, description: 'Text parsing operations' },
    { name: 'Priority Queue', icon: Database, description: 'Scoring and ranking' },
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-3 mb-4">
        {isTrainingComplete ? (
          <CheckCircle className="w-6 h-6 text-green-500" />
        ) : (
          <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        )}
        <h3 className="text-lg font-semibold text-gray-900">
          {isTraining ? 'Training Model...' : 'Training Complete!'}
        </h3>
      </div>

      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-1">
          <span>Training Progress</span>
          <span>{trainingDataSize} samples</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-500 ${
              isTrainingComplete
                ? 'bg-gradient-to-r from-green-500 to-green-600 w-full'
                : 'bg-gradient-to-r from-blue-500 to-purple-500 w-3/4 animate-pulse'
            }`}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {dataStructures.map((ds, index) => {
          const Icon = ds.icon;
          return (
            <div
              key={ds.name}
              className={`flex items-center space-x-3 p-3 rounded-lg transition-all duration-300 ${
                isTrainingComplete
                  ? 'bg-green-50 border border-green-200'
                  : 'bg-blue-50 border border-blue-200'
              }`}
            >
              <Icon className={`w-5 h-5 ${
                isTrainingComplete ? 'text-green-600' : 'text-blue-600'
              }`} />
              <div>
                <p className="font-medium text-sm text-gray-900">{ds.name}</p>
                <p className="text-xs text-gray-600">{ds.description}</p>
              </div>
            </div>
          );
        })}
      </div>

      {isTrainingComplete && (
        <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
          <p className="text-sm text-green-800">
            ✨ Model trained successfully using pure data structures! Ready for analysis.
          </p>
        </div>
      )}
    </div>
  );
};

export default TrainingStatus;