import React, { useState } from 'react';
import { Search, Zap } from 'lucide-react';

interface AnalysisInputProps {
  onAnalyze: (text: string) => void;
  isAnalyzing: boolean;
  canAnalyze: boolean;
}

const AnalysisInput: React.FC<AnalysisInputProps> = ({
  onAnalyze,
  isAnalyzing,
  canAnalyze,
}) => {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && canAnalyze && !isAnalyzing) {
      onAnalyze(text.trim());
    }
  };

  const exampleTexts = [
    "Scientists at MIT have published a peer-reviewed study showing significant breakthrough in renewable energy technology.",
    "SHOCKING: This one weird trick will make you rich overnight! Government doesn't want you to know this secret!",
    "According to the latest research data from multiple universities, climate change continues to impact global weather patterns."
  ];

  const loadExample = (example: string) => {
    setText(example);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <Search className="w-5 h-5 text-blue-600" />
        <span>Analyze News Content</span>
      </h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="news-text" className="block text-sm font-medium text-gray-700 mb-2">
            Paste news article or content to analyze
          </label>
          <textarea
            id="news-text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Enter the news article or content you want to analyze for authenticity..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none transition-all duration-200"
            rows={6}
            disabled={!canAnalyze}
          />
          <div className="flex justify-between items-center mt-2">
            <p className="text-xs text-gray-500">
              {text.length} characters
            </p>
            <p className="text-xs text-gray-500">
              Minimum 50 characters recommended
            </p>
          </div>
        </div>

        <button
          type="submit"
          disabled={!canAnalyze || !text.trim() || isAnalyzing || text.length < 20}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center space-x-2"
        >
          {isAnalyzing ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Analyzing...</span>
            </>
          ) : (
            <>
              <Zap className="w-5 h-5" />
              <span>Analyze Content</span>
            </>
          )}
        </button>
      </form>

      {!canAnalyze && (
        <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
          <p className="text-sm text-yellow-800">
            Please upload training data first to enable content analysis.
          </p>
        </div>
      )}

      <div className="mt-6">
        <h4 className="text-sm font-medium text-gray-700 mb-3">Try example texts:</h4>
        <div className="space-y-2">
          {exampleTexts.map((example, index) => (
            <button
              key={index}
              onClick={() => loadExample(example)}
              disabled={!canAnalyze}
              className="w-full text-left p-3 text-sm bg-gray-50 hover:bg-gray-100 rounded-lg border border-gray-200 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span className="text-gray-600">Example {index + 1}:</span>
              <br />
              <span className="text-gray-800">{example.substring(0, 100)}...</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnalysisInput;