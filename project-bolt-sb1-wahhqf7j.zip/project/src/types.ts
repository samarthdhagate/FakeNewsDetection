export interface TrainingData {
  text: string;
  label: 'fake' | 'real';
}

export interface AnalysisResult {
  verdict: 'fake' | 'real';
  confidence: number;
  suspiciousKeywords: string[];
  factDensityScore: number;
  details: {
    totalWords: number;
    suspiciousWordCount: number;
    factualIndicators: number;
    emotionalWords: number;
  };
}

export interface KeywordEntry {
  word: string;
  fakeCount: number;
  realCount: number;
  weight: number;
}