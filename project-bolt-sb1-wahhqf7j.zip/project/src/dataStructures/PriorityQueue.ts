interface PriorityItem<T> {
  item: T;
  priority: number;
}

export class PriorityQueue<T> {
  private heap: PriorityItem<T>[] = [];

  private parent(index: number): number {
    return Math.floor((index - 1) / 2);
  }

  private leftChild(index: number): number {
    return 2 * index + 1;
  }

  private rightChild(index: number): number {
    return 2 * index + 2;
  }

  private swap(i: number, j: number): void {
    [this.heap[i], this.heap[j]] = [this.heap[j], this.heap[i]];
  }

  enqueue(item: T, priority: number): void {
    this.heap.push({ item, priority });
    this.heapifyUp();
  }

  private heapifyUp(): void {
    let index = this.heap.length - 1;
    while (index > 0) {
      const parentIndex = this.parent(index);
      if (this.heap[parentIndex].priority <= this.heap[index].priority) {
        break;
      }
      this.swap(parentIndex, index);
      index = parentIndex;
    }
  }

  dequeue(): T | null {
    if (this.heap.length === 0) {
      return null;
    }

    if (this.heap.length === 1) {
      return this.heap.pop()!.item;
    }

    const root = this.heap[0].item;
    this.heap[0] = this.heap.pop()!;
    this.heapifyDown();
    return root;
  }

  private heapifyDown(): void {
    let index = 0;
    while (this.leftChild(index) < this.heap.length) {
      const leftIndex = this.leftChild(index);
      const rightIndex = this.rightChild(index);
      let smallestIndex = leftIndex;

      if (
        rightIndex < this.heap.length &&
        this.heap[rightIndex].priority < this.heap[leftIndex].priority
      ) {
        smallestIndex = rightIndex;
      }

      if (this.heap[index].priority <= this.heap[smallestIndex].priority) {
        break;
      }

      this.swap(index, smallestIndex);
      index = smallestIndex;
    }
  }

  peek(): T | null {
    return this.heap.length > 0 ? this.heap[0].item : null;
  }

  isEmpty(): boolean {
    return this.heap.length === 0;
  }

  size(): number {
    return this.heap.length;
  }

  toSortedArray(): T[] {
    const result: T[] = [];
    const tempQueue = new PriorityQueue<T>();
    
    // Copy all items to temp queue
    for (const item of this.heap) {
      tempQueue.enqueue(item.item, item.priority);
    }
    
    // Extract all items in sorted order
    while (!tempQueue.isEmpty()) {
      result.push(tempQueue.dequeue()!);
    }
    
    return result;
  }
}