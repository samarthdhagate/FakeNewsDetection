class BSTNode<T> {
  value: T;
  left: BSTNode<T> | null = null;
  right: BSTNode<T> | null = null;

  constructor(value: T) {
    this.value = value;
  }
}

export class BST<T> {
  private root: BSTNode<T> | null = null;
  private compareFunction: (a: T, b: T) => number;

  constructor(compareFunction: (a: T, b: T) => number) {
    this.compareFunction = compareFunction;
  }

  insert(value: T): void {
    this.root = this.insertNode(this.root, value);
  }

  private insertNode(node: BSTNode<T> | null, value: T): BSTNode<T> {
    if (node === null) {
      return new BSTNode(value);
    }

    const comparison = this.compareFunction(value, node.value);
    if (comparison < 0) {
      node.left = this.insertNode(node.left, value);
    } else if (comparison > 0) {
      node.right = this.insertNode(node.right, value);
    }

    return node;
  }

  search(value: T): boolean {
    return this.searchNode(this.root, value);
  }

  private searchNode(node: BSTNode<T> | null, value: T): boolean {
    if (node === null) {
      return false;
    }

    const comparison = this.compareFunction(value, node.value);
    if (comparison === 0) {
      return true;
    } else if (comparison < 0) {
      return this.searchNode(node.left, value);
    } else {
      return this.searchNode(node.right, value);
    }
  }

  inorderTraversal(): T[] {
    const result: T[] = [];
    this.inorder(this.root, result);
    return result;
  }

  private inorder(node: BSTNode<T> | null, result: T[]): void {
    if (node !== null) {
      this.inorder(node.left, result);
      result.push(node.value);
      this.inorder(node.right, result);
    }
  }

  findMatches(text: string): T[] {
    const matches: T[] = [];
    this.findMatchesInNode(this.root, text.toLowerCase(), matches);
    return matches;
  }

  private findMatchesInNode(node: BSTNode<T> | null, text: string, matches: T[]): void {
    if (node === null) {
      return;
    }

    const nodeValueStr = String(node.value).toLowerCase();
    if (text.includes(nodeValueStr)) {
      matches.push(node.value);
    }

    this.findMatchesInNode(node.left, text, matches);
    this.findMatchesInNode(node.right, text, matches);
  }
}