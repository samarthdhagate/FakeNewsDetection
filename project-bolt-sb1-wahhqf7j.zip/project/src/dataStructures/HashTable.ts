export class HashTable<T> {
  private size: number;
  private buckets: Array<Array<{ key: string; value: T }>>;

  constructor(size: number = 1000) {
    this.size = size;
    this.buckets = new Array(size).fill(null).map(() => []);
  }

  private hash(key: string): number {
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      const char = key.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash) % this.size;
  }

  set(key: string, value: T): void {
    const index = this.hash(key);
    const bucket = this.buckets[index];
    
    const existingItem = bucket.find(item => item.key === key);
    if (existingItem) {
      existingItem.value = value;
    } else {
      bucket.push({ key, value });
    }
  }

  get(key: string): T | null {
    const index = this.hash(key);
    const bucket = this.buckets[index];
    const item = bucket.find(item => item.key === key);
    return item ? item.value : null;
  }

  has(key: string): boolean {
    return this.get(key) !== null;
  }

  keys(): string[] {
    const keys: string[] = [];
    for (const bucket of this.buckets) {
      for (const item of bucket) {
        keys.push(item.key);
      }
    }
    return keys;
  }
}