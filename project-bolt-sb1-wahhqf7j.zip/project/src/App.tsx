import React, { useState, useCallback } from 'react';
import { Shield, Brain, Database } from 'lucide-react';
import FileUpload from './components/FileUpload';
import TrainingStatus from './components/TrainingStatus';
import AnalysisInput from './components/AnalysisInput';
import AnalysisResult from './components/AnalysisResult';
import { FakeNewsDetector } from './engine/FakeNewsDetector';
import { parseCSV } from './utils/csvParser';
import { TrainingData, AnalysisResult as AnalysisResultType } from './types';

function App() {
  const [detector] = useState(() => new FakeNewsDetector());
  const [isUploading, setIsUploading] = useState(false);
  const [isTraining, setIsTraining] = useState(false);
  const [isTrainingComplete, setIsTrainingComplete] = useState(false);
  const [trainingDataSize, setTrainingDataSize] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResultType | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileLoad = useCallback(async (csvContent: string) => {
    setIsUploading(true);
    setError(null);
    
    try {
      const trainingData: TrainingData[] = await parseCSV(csvContent);
      setTrainingDataSize(trainingData.length);
      
      setIsTraining(true);
      setIsTrainingComplete(false);
      
      // Simulate training delay to show the process
      setTimeout(() => {
        detector.train(trainingData);
        setIsTraining(false);
        setIsTrainingComplete(true);
      }, 2000);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error processing file');
    } finally {
      setIsUploading(false);
    }
  }, [detector]);

  const handleAnalyze = useCallback(async (text: string) => {
    setIsAnalyzing(true);
    setError(null);
    
    try {
      // Simulate analysis delay to show the process
      setTimeout(() => {
        const result = detector.analyze(text);
        setAnalysisResult(result);
        setIsAnalyzing(false);
      }, 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error analyzing text');
      setIsAnalyzing(false);
    }
  }, [detector]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Fake News Detector
              </h1>
              <p className="text-gray-600 mt-1">
                Pure Data Structures & Algorithms Implementation
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-800 font-medium">Error</p>
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        {/* Data Structures Info */}
        <div className="mb-8 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Brain className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-semibold text-gray-900">
              Pure Data Structures Implementation
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2 p-3 bg-blue-50 rounded-lg">
              <Database className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900 text-sm">Hash Tables</p>
                <p className="text-blue-700 text-xs">O(1) keyword lookup</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 p-3 bg-green-50 rounded-lg">
              <Database className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-green-900 text-sm">Binary Search Tree</p>
                <p className="text-green-700 text-xs">Phrase organization</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 p-3 bg-purple-50 rounded-lg">
              <Database className="w-5 h-5 text-purple-600" />
              <div>
                <p className="font-medium text-purple-900 text-sm">Stack</p>
                <p className="text-purple-700 text-xs">Text parsing</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 p-3 bg-orange-50 rounded-lg">
              <Database className="w-5 h-5 text-orange-600" />
              <div>
                <p className="font-medium text-orange-900 text-sm">Priority Queue</p>
                <p className="text-orange-700 text-xs">Score ranking</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            <FileUpload 
              onFileLoad={handleFileLoad}
              isLoading={isUploading}
            />
            
            <TrainingStatus
              isTraining={isTraining}
              isTrainingComplete={isTrainingComplete}
              trainingDataSize={trainingDataSize}
            />
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <AnalysisInput
              onAnalyze={handleAnalyze}
              isAnalyzing={isAnalyzing}
              canAnalyze={isTrainingComplete}
            />
          </div>
        </div>

        {/* Analysis Results */}
        {analysisResult && (
          <div className="mt-8">
            <AnalysisResult result={analysisResult} />
          </div>
        )}

        {/* Instructions */}
        {!isTrainingComplete && (
          <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 border border-blue-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">How to Use</h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p><strong>Step 1:</strong> Upload a CSV file with columns for text content and labels (fake/real or 1/0)</p>
              <p><strong>Step 2:</strong> Wait for the training process to complete using our custom data structures</p>
              <p><strong>Step 3:</strong> Enter news content in the analysis box to get predictions</p>
              <p className="text-xs text-gray-600 mt-3">
                This implementation uses only pure data structures (no ML libraries) for educational demonstration.
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;